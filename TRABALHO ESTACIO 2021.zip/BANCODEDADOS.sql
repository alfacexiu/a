-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 20-Jun-2021 às 20:04
-- Versão do servidor: 10.3.16-MariaDB
-- versão do PHP: 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `id16881514_dbdfalt`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `bancodedados1`
--

CREATE TABLE `bancodedados1` (
  `id` int(10) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `senha` varchar(50) NOT NULL,
  `sobrenome` text NOT NULL,
  `cpf` varchar(220) NOT NULL,
  `telefone` varchar(100) NOT NULL,
  `instagram` varchar(220) NOT NULL,
  `endum` varchar(220) NOT NULL,
  `endois` varchar(220) NOT NULL,
  `stado` text NOT NULL,
  `cep` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `bancodedados1`
--

INSERT INTO `bancodedados1` (`id`, `nome`, `email`, `senha`, `sobrenome`, `cpf`, `telefone`, `instagram`, `endum`, `endois`, `stado`, `cep`) VALUES
(6, 'Carlos', 'carloshrbarros09@gmail.com', 'testeadmin', 'Barros', '178.241.917-96', '(21) 99545-3037', 'Alface.xiu', 'teste', 'teste', 'Rio de Janeiro', '21041-115'),
(8, 'Luiz', 'admin@admin.com', '123', 'Juliano', '178.544.987-89', '(32)13213-2132', 'testeadmin', 'teste de rua', 'skdjkasd', 'PA', '21041030'),
(9, 'CARLOS', 'carloshrbarros09@gmail.com', '23456789', 'BARROS', '178.241.917-96', '(21)99545-3037', 'dfaltshopp', 'Avenida Londres', '350 - Casa 2', 'RJ', '21041030'),
(10, 'CARLOS', 'carloshrbarros09@gmail.com', 'sdfghjkh', 'BARROS', '178.241.917-96', '(21)99545-3037', 'kkkkkkkkkkk', 'Avenida Londres', '350 - Casa 2', 'RJ', '21041030'),
(11, 'CARLOS', 'carloshrbarros09@gmail.com', 'frtgyhuj', 'BARROS', '178.241.917-96', '(21)99545-3037', 'dfaltshopp', 'Avenida Londres', '350 - Casa 2', 'RJ', '21041030'),
(12, 'CARLOS', 'carloshrbarros09@gmail.com', '3456789u', 'BARROS', '178.241.917-96', '(21)99545-3037', 'kkkkkkkkkkk', 'Avenida Londres', '350 - Casa 2', 'RJ', '21041030'),
(13, 'CARLOS', 'carloshrbarros09@gmail.com', 'dfghjykl', 'BARROS', '178.241.917-96', '(21)99545-3037', 'testeadmin', 'Avenida Londres', '350 - Casa 2', 'RJ', '21041030'),
(14, 'CARLOS', 'carloshrbarros09@gmail.com', 'cxvghjkh', 'BARROS', '178.241.917-96', '(21)99545-3037', 'testeadmin', 'Avenida Londres', '350 - Casa 2', 'RJ', '21041030'),
(15, 'CARLOS', 'carloshrbarros09@gmail.com', 'cxvghjkh', 'BARROS', '178.241.917-96', '(21)99545-3037', 'testeadmin', 'Avenida Londres', '350 - Casa 2', 'RJ', '21041030'),
(16, 'Otario', 'teste@gmail.com', '12132132', 'Burro', '178.241.917-96', '(21)99545-3037', 'eoteste', 'qwertyui', 'oiuytrewq', 'RJ', '21041030'),
(17, 'Nsuka dilusala ', 'albertnsuka156@gmail.com', '110620', 'Albert ', '064.396.007-45', '(21)98700-5386', '@albert_nsuka ', 'Rua barao de sao feliz 92', 'Fundos ', 'RJ', '21221425');

-- --------------------------------------------------------

--
-- Estrutura da tabela `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `image` varchar(220) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `image`) VALUES
(31, 'Carlos atualizou', 'Eu mesmokkk', 100122, 'kkkkk.png');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `senha` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `email`, `senha`) VALUES
(1, 'admin@admin.com', '123'),
(2, 'root@admin.com', '123'),
(3, 'admyin@admin.com', 'yyyyyy'),
(4, 'xablazinht2@gmail.com', '123'),
(5, 'carloshrbarros09@gmail.com', '8115'),
(6, 'carloshrbarros09@gmail.com', '8115'),
(7, 'teste@gmail.com', '123'),
(8, 'admin@rooot.com', '123'),
(9, 'xablazinht22@gmail.com', '222222222'),
(10, 'carloshrbarros09@gmail.com', 'sssss'),
(11, 'carloshrbarros09@gmail.com', 'sssss'),
(12, 'milenagabriely23@gmail.com', '86810817'),
(13, 'Admin@roooot@gmail.com', '811581'),
(14, 'admin@a.com', '123'),
(15, 'ssss@gmail.com', 'asdasd'),
(16, 'Carlinhos@gmail.com', '123');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `bancodedados1`
--
ALTER TABLE `bancodedados1`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `bancodedados1`
--
ALTER TABLE `bancodedados1`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
