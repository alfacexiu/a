<?php
session_start();
require_once("Banco.php");

if (! isset($_SESSION["autenticado"])){
    
    header('Location: ./index.php');
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    
    <title>Adlyn - cPanel</title>
  </head>
  <body>
    
    <nav class="navbar navbar-expand-lg navbar-light bg-light" aria-label="Eighth navbar example">
    <div class="container">
      <a class="navbar-brand" href="./dashboard.php">dFalt Shopp Ecommerce</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample07" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample07">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="./dashboard.php">Início</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="./cdproducts.php">Cadastrar Produto</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="./dltproducts.php">Excluir Produto</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="?sair">Sair</a>
<?php
if(isset($_GET['sair'])){
        session_destroy();
        echo '<meta http-equiv="refresh" content="0; url=./index.php" />';
        die();
    }
?>
          </li>
        </ul>
      </div>
    </div>
  </nav>
    <center>
        <h1>Adlyn - Cadastrar Produtos</h1>
    </center>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    
    <div class="container">
        
        <form method="post">
            <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">Nome do Produto</label>
              <input type="text" class="form-control" name="nameprodut" required>
            </div>
            <div class="mb-3">
              <label for="exampleFormControlTextarea1" class="form-label">Descrição</label>
              <textarea class="form-control" name="descricao" rows="3" required></textarea>
            </div>
             <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">Valor R$ - colocar com (.) e não com (,)</label>
              <input type="number" min="0" step="0.01" class="form-control" name="valor" required>
            </div>
              
            <input type="submit" value="Cadastrar" class="btn btn-success" role="button" name="btn">
            
<?php
    
    if(isset($_POST['btn'])){
        
        $nomeproduto = $_POST['nameprodut'];
        $descript = $_POST['descricao'];
        $price = $_POST['valor'];
        $urlimg = "kkkkk.png";
        
        try {
            
            $user = 'id16881514_root';
            $pass = 'Xb*f8/YmORA)m!^P';

            $pdo = new PDO('mysql:host=localhost;dbname=id16881514_dbdfalt', $user, $pass);
            
            $stmt = $pdo->prepare("INSERT INTO `products` (`id`, `name`, `description`, `price`, `image`) VALUES (NULL, :name, :description, :price, :image);");
            
            $stmt-> bindParam(":name", $nomeproduto);
            $stmt-> bindParam(":description", $descript);
            $stmt-> bindParam(":price", $price);
            $stmt-> bindParam(":image", $urlimg);
            
            $stmt->execute(); 
            
            
            echo "<center> <br><div class='alert alert-primary' role='alert'>Produto Cadastrado com Sucesso!</div></center>";
            
            echo '<meta http-equiv="refresh" content="2; url=./dashboard.php" />';

            
            }   catch(PDOException $e) {
                echo 'Error: ' . $e->getMessage();
            }
    }
?>            

        </form>
    <br>
    <br>
    </div>

    <script>
        
    </script>
  </body>
</html>