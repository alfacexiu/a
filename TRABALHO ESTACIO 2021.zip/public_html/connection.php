<?php

	$host = "localhost";
	$user = "id16881514_root";
	$pass = "Xb*f8/YmORA)m!^P";
	$dbname = "id16881514_dbdfalt";
	$port = 3006;

	try {
		$conn = new PDO("mysql:host=$host;dbname=" . $dbname, $user, $pass);
		//echo "Connection Database Sucess!";
	} catch (Exception $e) {
		die("Failled Connection in dataBase.");
	}

?>