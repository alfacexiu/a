<?php
session_start();
require_once("Banco.php");
include_once './connection.php';

if (! isset($_SESSION["autenticado"])){
    
    header('Location: ./index.php');
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    
    <title>Adlyn - cPanel</title>
  </head>
  <body>
    
    <nav class="navbar navbar-expand-lg navbar-light bg-light" aria-label="Eighth navbar example">
    <div class="container">
      <a class="navbar-brand" href="./dashboard.php">dFalt Shopp Ecommerce</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample07" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample07">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="./dashboard.php">Início</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="./cdproducts.php">Cadastrar Produto</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="./dltproducts.php">Excluir Produto</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="?sair">Sair</a>
<?php
if(isset($_GET['sair'])){
        session_destroy();
        echo '<meta http-equiv="refresh" content="0; url=./index.php" />';
        die();
    }
?>
          </li>
        </ul>
      </div>
    </div>
  </nav>
    <center>
        <h1>Adlyn - Produtos</h1>
    </center>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    
    <div class="container">
        
        <form method="post">
               <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">

                <?php 
                 $query_products = "SELECT id, name, price, image FROM products ORDER BY id DESC";
                 $result_products = $conn->prepare($query_products);
                 $result_products->execute();
                 ?>

                <?php
                 while($row_product = $result_products->fetch(PDO::FETCH_ASSOC)){
                    extract($row_product);
                ?>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src='<?php echo "./images/products/dfalt/banner.jpg"; ?>' alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder"><?php echo "$name"; ?></h5>
                                    <!-- Product reviews-->
                                    <!-- CODE HERE     -->
                                    <!-- Product price-->
                                    <b> R$<?php echo number_format($price, 2, ",", "."); ?></b>
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="exclui2.php?id=<?php echo $id; ?>">Excluir Produto</a>
                                </div>
                            </div>
                        </div>
                    </div>
                 <?php
                 }
                 ?>
               </div>
        </form>
    <br>
    <br>
    </div>

    <script>
        
    </script>
  </body>
</html>