<?php
session_start();

require_once("Banco.php");

$email = $_POST['email'];
$senha = $_POST['pass'];

$pdo =  new Banco();

$sql = "SELECT * from users where email ='$email' and senha ='$senha' ";
$result = $pdo->query($sql);


if (empty($result->rowCount())) {
    unset($_SESSION["autenticado"]);
   header('Location: ./login.php');
}else{
    $_SESSION["autenticado"]=true;
     header('Location: ./dashboard.php');
}

?>