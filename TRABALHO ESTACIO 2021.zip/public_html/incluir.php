<?php
    
    if(isset($_POST['btn'])){
        

        $email = $_POST['email'];  
        $senha = $_POST['pass'];
        $nomeproduto = $_POST['nameprodut'];
        $descript = $_POST['descricao'];
        $price = $_POST['valor'];
        $urlimg = "kkkkk.png";
        
        try {
            
            $user = 'id16881514_root';
            $pass = 'Xb*f8/YmORA)m!^P';

            $pdo = new PDO('mysql:host=localhost;dbname=id16881514_dbdfalt', $user, $pass);

            $stmt = $pdo->prepare('INSERT INTO products (id, name , description , price , image, created , modified) VALUES(NULL, :name, :description, :price, NULL, NULL, NULL)');
            
            $stmt-> bindParam(":name", $nomeproduto);
            $stmt-> bindParam(":description", $descript);
            $stmt-> bindParam(":price", $price);
            $stmt-> bindParam(":image", $urlimg);
            
            $stmt->execute(); 
            
            $_SESSION["autenticado"]=true;
            
            
            echo "<center> <div class='alert alert-primary' role='alert'>Produto Cadastrado com Sucesso!</div></center>";
            
            echo '<meta http-equiv="refresh" content="2; url=./index.php" />';

            }   catch(PDOException $e) {
                echo 'Error: ' . $e->getMessage();
            }
    }
?>