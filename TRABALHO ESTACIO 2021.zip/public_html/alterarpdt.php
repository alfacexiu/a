<?php
session_start();
require_once("Banco.php");

if (! isset($_SESSION["autenticado"])){
    header('Location: ./index.php');
}else{
    ob_start();
    
    $id = filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT);
    
    if (empty($id)){
      header("Location: ./dashboard.php");
      die("Error 404.<br>");
    }
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    
    <title>Adlyn - cPanel</title>
  </head>
  <body>
<?php
    include_once './connection.php';
    
    // Pesquisar a informação do produto db
    $query_products = "SELECT id, name, price, description FROM products WHERE id = :id LIMIT 1";
    $result_products = $conn->prepare($query_products);
    $result_products->bindParam(':id', $id, PDO::PARAM_INT);
    $result_products->execute();
    if($result_products->rowCount() == 0){
        header("Location: ./index.php");
        die("Error 404.<br>");
    }
    $row_product = $result_products->fetch(PDO::FETCH_ASSOC);
    extract($row_product);
?>
    
    <nav class="navbar navbar-expand-lg navbar-light bg-light" aria-label="Eighth navbar example">
    <div class="container">
      <a class="navbar-brand" href="./dashboard.php">dFalt Shopp Ecommerce</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample07" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample07">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="./dashboard.php">Início</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="./cdproducts.php">Cadastrar Produto</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="./dltproducts.php">Excluir Produto</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="?sair">Sair</a>
<?php
if(isset($_GET['sair'])){
        session_destroy();
        echo '<meta http-equiv="refresh" content="0; url=./index.php" />';
        die();
    }
?>
          </li>
        </ul>
      </div>
    </div>
  </nav>
    <center>
        <h1>Adlyn - Alterar Informações</h1>
    </center>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    
    <div class="container">
        
        <form method="post">
            <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">Nome do Produto </label>
              <input type="text" class="form-control" name="nameprodut" value="<?php echo $name; ?>" required>
            </div>
            <div class="mb-3">
              <label for="exampleFormControlTextarea1" class="form-label">Descrição</label>
              <input type="text" class="form-control" name="descricao" value="<?php echo $description; ?>" required>
            </div>
             <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">Valor R$ - colocar com (.) e não com (,)</label>
              <input type="number" min="0" step="0.01" class="form-control" name="valor" value="<?php echo $price; ?>" required>
              
            </div>
              
            <input type="submit" value="Atualizar" class="btn btn-success" role="button" name="btn">
<?php
    if(isset($_POST['btn'])){
        
        $namepdt = $_POST['nameprodut'];
        $desc = $_POST['descricao'];
        $vaule = $_POST['valor'];
        
        $query_products = "UPDATE products SET name = '$namepdt', description = '$desc', price = '$vaule' WHERE products.id = :id";

        $result_products = $conn->prepare($query_products);
        $result_products->bindParam(':id', $id, PDO::PARAM_INT);
        $result_products->execute();
            
        echo "<center><br><div class='alert alert-primary' role='alert'>Produto atualizado com Sucesso!</div></center>";
        echo '<meta http-equiv="refresh" content="1; url=./dashboard.php" />';
    } 
?>
        </form>
    <br>
    <br>
    </div>

    <script>
        
    </script>
  </body>
</html>