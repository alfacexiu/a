<?php
session_start();

require_once("Banco.php");

$email = $_POST['email'];
$senha = $_POST['pass'];

$pdo =  new Banco();

$sql = "INSERT INTO users (id, email, senha) VALUES (NULL, '$email', '$senha'";

$result = $pdo->query($sql);

$_SESSION["autenticado"]=true;
header('Location: ./dashboard.php');
     
?>