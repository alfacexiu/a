<?php
session_start();
if (! isset($_SESSION["autenticado"])){
    header('Location: ./index.php');
}else{
        ob_start();

        $id = filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT);
        if (empty($id)){
            header("Location: ./index.php");
            die("Error 404.<br>");
        }
	    include_once './connection.php';

}
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title>dFalt - cPanel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  </head>
  <body><br><br>
<?php
	    $id = filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT);

            $query_products = "DELETE FROM products WHERE id= :id";
            $result_products = $conn->prepare($query_products);
            $result_products->bindParam(':id', $id, PDO::PARAM_INT);
            $result_products->execute();
            
            echo "<center> <div class='alert alert-primary' role='alert'>Produto excluído com Sucesso!</div></center>";
            echo '<meta http-equiv="refresh" content="1; url=./dashboard.php" />';
?>
  </body>
</html>
