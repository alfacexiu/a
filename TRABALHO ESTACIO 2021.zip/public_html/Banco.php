<?php

class Banco {
    
    private $pdo;
    
    function __construct(){
        
        $user = 'id16881514_root';
        $pass = 'Xb*f8/YmORA)m!^P';

        $this->pdo = new PDO('mysql:host=localhost;dbname=id16881514_dbdfalt', $user, $pass);
    }
    
    /**
     * Metodo Query
     * Realiza uma consulta ao banco de dados
     * @example comando select do sql
     **/
    function query($sql){
        return $this->pdo->query($sql);
    }
    
    /**
     * Metodo Exec
     * Realiza uma acao ao banco de dados
     * @example comandos : insert, update e delete do sql
     **/
     
    function exec($sql){
        return $this->pdo->exec($sql);
    }
    
}



?>