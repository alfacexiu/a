<?php
    ob_start();

    $id = filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT);
    if (empty($id)){
      header("Location: ./index.php");
      die("Error 404.<br>");
    }

    include_once './connection.php';
    
    // Pesquisar a informação do produto db
    $query_products = "SELECT id, name, price FROM products WHERE id = :id LIMIT 1";
    $result_products = $conn->prepare($query_products);
    $result_products->bindParam(':id', $id, PDO::PARAM_INT);
    $result_products->execute();
    if($result_products->rowCount() == 0){
        header("Location: ./index.php");
        die("Error 404.<br>");
    }
    $row_product = $result_products->fetch(PDO::FETCH_ASSOC);
    extract($row_product);


?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.83.1">
    <title>dFalt📦Shopp · Checkout</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/checkout/">
    <!-- Bootstrap core CSS -->
<link href="./checkout-two/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    
    <!-- Custom styles for this template -->
    <link href="./checkout-two/form-validation.css" rel="stylesheet">
  </head>
  <body class="bg-light">

<?php

  include_once "./menu.php";

  //recebendo os dados do form.
  $data = filter_input_array(INPUT_POST, FILTER_DEFAULT); 
  
  //variavel recebendo mensagem de erro
  $msg = "";

  if(isset($data['BtnfinPicpay'])){
    //var_dump($data);  var dump bb

  $empty_Input = false;
  $data = array_map('trim', $data);

  if(in_array("", $data)){
    $empty_Input = true;
    $msg = "<div class='alert alert-danger' role='alert'>Error: Necessário preencher todos os campos!</div>";
  } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
    $empty_Input = true;
    $msg = "<div class='alert alert-danger' role='alert'>Error: Necessário preencher com email válido!</div>";
  }
  //acessa o if qnd nao tem erro
  if (!$empty_Input){
            
            $msg = "<center> <div class='alert alert-primary' role='alert'>Pedido gerado com sucesso!</div></center>";
            
            echo "<meta http-equiv='refresh' content='2; url=https://api.whatsapp.com/send?phone=5521995453037&text=Ol%C3%A1%2C%20Carlos.%20Fiquei%20interessado(a)%20no $name.' />";
            
  }
}
?>

<div class="container">
  <main>
    <div class="py-5 text-center">
      <img class="d-block mx-auto mb-4" src="./img/banner.jpg" alt="" width="80" height="80">
      <h2>💸</h2>
      <p class="lead">Agradecemos a preferência em escolher a dFalt para proporcionar as melhores vantagens.<br>Boas compras ;D</p>
    </div>

    <div class="row g-5">
      <div class="col-md-5 col-lg-4 order-md-last">
        <h4 class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-primary">Resumo</span>
          <span class="badge bg-primary rounded-pill">1</span>
        </h4>
        <ul class="list-group mb-3">
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0"><?php echo $name; ?></h6>
              <small class="text-muted">Produto</small>
            </div>
            <span class="text-muted">R$<?php echo number_format($price, 2, ",", "."); ?></span>
          </li>
          <li class="list-group-item d-flex justify-content-between bg-light">
            <div class="text-success">
              <h6 class="my-0">Código Promocional</h6>
              <small>CODPROMO5</small>
            </div>
            <span class="text-success">−$5</span>
          </li>
          <li class="list-group-item d-flex justify-content-between">
            <span>Total (BRL)</span>
            <strong><?php $desconto = 5; $price_end = ($price - $desconto); echo number_format($price_end, 2, ",", "."); ?></strong>
          </li>
        </ul>

        <form class="card p-2">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Digite o código">
            <button type="submit" class="btn btn-secondary">VALIDAR</button>
          </div>
        </form>
      </div>
      <div class="col-md-7 col-lg-8">
        <h4 class="mb-3">Dados Pessoais</h4>
        <?php
          if (!empty($msg)){
            echo $msg;
            $msg = "";
          }
        ?>
        <form method="POST" class="needs-validation" novalidate>
          <div class="row g-3">
            <div class="col-sm-6">
              <label for="firstName" class="form-label">Primeiro Nome</label>
              <input type="text" class="form-control" name="firstName" id="firstName" placeholder="" value="<?php  if(isset($data['firstName'])){ echo $data['firstName']; } ?>" required>
              <div class="invalid-feedback">
                Primeiro nome é obrigatório.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="lastName" class="form-label">Último Nome</label>
              <input type="text" class="form-control" name="lastName" id="lastName" placeholder="" value="<?php  if(isset($data['lastName'])){ echo $data['lastName']; } ?>" required>
              <div class="invalid-feedback">
                Último nome é obrigatório.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="cpf" class="form-label">CPF</label>
              <input type="text" name="cpf" id="cpf" class="form-control" placeholder="Somente número do CPF" maxlength="14" oninput="maskCPF(this)" value="<?php  if(isset($data['cpf'])){ echo $data['cpf']; } ?>" required>
              <div class="invalid-feedback">
                CPF é obrigatório.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="phone" class="form-label">Telefone</label>
              <input type="text" name="phone" id="phone" class="form-control" placeholder="Telefone com o DDD" maxlength="14" oninput="maskPhone(this)" value="<?php  if(isset($data['phone'])){ echo $data['phone']; } ?>" required>
              <div class="invalid-feedback">
                Telefone é obrigatório.
              </div>
            </div>

            <div class="col-12">
              <label for="username" class="form-label">Instagram</label>
              <div class="input-group has-validation">
                <span class="input-group-text">@</span>
                <input type="text" class="form-control" name="username" id="username" placeholder="Username" value="<?php  if(isset($data['username'])){ echo $data['username']; } ?>" required>
                <div class="invalid-feedback">
                Seu @usuário é obrigatório. Chamaremos caso haja urgência ^^
              </div>
              </div>
            </div>

            <div class="col-12">
              <label for="email" class="form-label">Email</label>
              <input type="email" class="form-control" name="email" id="email" placeholder="you@email.com" value="<?php  if(isset($data['email'])){ echo $data['email']; } ?>" required>
              <div class="invalid-feedback">
              Seu Email é obrigatório. Em caso de emergência, chamaremos por lá ;)
              </div>
            </div>

            <div class="col-12">
              <label for="address" class="form-label">Endereço</label>
              <input type="text" class="form-control" name="address" id="address" placeholder="Rua Exemplo, 347" value="<?php  if(isset($data['address'])){ echo $data['address']; } ?>" required>
              <div class="invalid-feedback">
                Seu <b>endereço</b> é obrigatório.
              </div>
            </div>

            <div class="col-12">
              <label for="address2" class="form-label">Complemento</label>
              <input type="text" class="form-control" name="address2" id="address2" placeholder="Se não houver complemento, digitar: s/c." value="<?php  if(isset($data['address2'])){ echo $data['address2']; } ?>" required>
            </div>

            <div class="col-md-4">
              <label for="state" class="form-label">Estado</label>
              <select class="form-select" name="state" id="state" required>
                <option value="">Selecionar</option>
                <option value="AC">Acre</option>
                <option value="AL">Alagoas</option>
                <option value="AP">Amapá</option>
                <option value="AM">Amazonas</option>
                <option value="BA">Bahia</option>
                <option value="CE">Ceará</option>
                <option value="DF">Distrito Federal</option>
                <option value="ES">Espírito Santo</option>
                <option value="GO">Goiás</option>
                <option value="MA">Maranhão</option>
                <option value="MT">Mato Grosso</option>
                <option value="MS">Mato Grosso do Sul</option>
                <option value="MG">Minas Gerais</option>
                <option value="PA">Pará</option>
                <option value="PB">Paraíba</option>
                <option value="PR">Paraná</option>
                <option value="PE">Pernambuco</option>
                <option value="PI">Piauí</option>
                <option value="RJ">Rio de Janeiro</option>
                <option value="RN">Rio Grande do Norte</option>
                <option value="RS">Rio Grande do Sul</option>
                <option value="RO">Rondônia</option>
                <option value="RR">Roraima</option>
                <option value="SC">Santa Catarina</option>
                <option value="SP">São Paulo</option>
                <option value="SE">Sergipe</option>
                <option value="TO">Tocantins</option>
              </select>
              <div class="invalid-feedback">
                Informe o seu estado.
              </div>
            </div>

            <div class="col-md-3">
              <label for="zip" class="form-label">CEP</label>
              <input type="text" class="form-control" name="zip" id="zip" placeholder="Ex: 12311020" maxlength="8" value="<?php  if(isset($data['zip'])){ echo $data['zip']; } ?>" required>
              <div class="invalid-feedback">
                Informe o seu CEP. não sabe o seu CEP? <a href="http://www.buscacep.correios.com.br/sistemas/buscacep/default.cfm" target="_blank">Clique Aqui</a>
              </div>
            </div>
            
            <div class="col-md-3">
              <label class="form-label">Senha</label>
              <input type="password" class="form-control" name="pass" id="pass" placeholder="Até 8 dígitos" maxlength="8" value="<?php  if(isset($data['pass'])){ echo $data['pass']; } ?>" required>
            </div>
          </div>

          <hr class="my-4">
          <!-- payments forms -->
          <button type="submit" name="BtnfinPicpay" id="BtnfinPicpay" class="w-100 btn btn-success btn-lg" value="BtnfinPicpay">Continue para finalizar a compra</button>
        </form>
      </div>
    </div>
  </main>

  <footer class="my-5 pt-5 text-muted text-center text-small">
    <p class="mb-1">&copy; 2021 dFalt📦Shopp</p>
    <ul class="list-inline">
      <li class="list-inline-item"><a href="#">Privacidade</a></li>
      <li class="list-inline-item"><a href="#">Termos</a></li>
      <li class="list-inline-item"><a href="#">Suporte & Ajuda</a></li>
    </ul>
  </footer>
</div>


    <script src="./checkout-two/bootstrap.bundle.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="./checkout-two/form-validation.js"></script>
  </body>
</html>