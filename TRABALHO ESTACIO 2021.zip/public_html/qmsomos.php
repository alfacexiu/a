<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>dFalt Shopp - Página Inicial</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#!">dFalt Shopp Ecommerce</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="./index.php">Início</a></li>
                        <li class="nav-item"><a class="nav-link" href="./qmsomos.php">Quem Somos?</a></li>
                    </ul>
                    <form class="d-flex">         
                        <a href="login.php" class="btn btn-outline-dark">
                            <i class="bi bi-people-fill"></i>
                            Área do Usuário
                        </a>
                    </form>
                    --
                    <form class="d-flex">         
                        <a href="register.php" class="btn btn-outline-dark">
                            <i class="bi bi-person-plus-fill"></i>
                            Registrar-se
                        </a>
                    </form>
                </div>
            </div>
        </nav>
        <!-- Header-->
        <header class="bg-dark py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <img src="img/banner.jpg">
                    <p class="lead fw-normal text-white-50 mb-0">OS MELHORES PRODUTOS COM <B>FRETE GRÁTIS.</B></p>
                </div>
            </div>
        </header>
        <!-- Section-->
        <section class="py-5">
            <div class="container px-4 px-lg-5 mt-5">
               <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                    <center>
                        <h2>Quem Somos?</h2>
                    </center>
                        <p>Somos uma empresa focada em encontrar os melhores preços e produtos para você, consumidor que busca vantagens e qualidades. Tudo isso com <b>FRETE GRÁTIS</b> para todo o Brasil!</p>
                        <br>
                    <center>
                        <h2>Criadores da dFalt</h2>
                    </center>
                        <p>A dFalt surgiu através de dois amigos, estavam pensando em criar uma loja de dropshipping porém não sabiam nenhum nome até que um deles falou: precisamos ser o padrão! Foi ai que o outro entendeu: padrao e associou com "default"- padrao em inglês, surgindo assim dFalt.<br> <b>Hoje com um faturamento de R$1.000.000,00 a.a</b></p>
               </div>
            </div>
        </section>
        <!-- Footer-->
        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; dFalt📦Shopp 2021</p></div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>